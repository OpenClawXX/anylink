package utils

import (
	"crypto/rand"
	"encoding/base64"
	mt "math/rand"

	"golang.org/x/crypto/bcrypt"
)

func PasswordHash(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	return string(bytes), err
}

func PasswordVerify(password, hash string) bool {
	// 保留老用户明文验证
	if len(hash) != 60 {
		return password == hash
	}
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

// $sha-256$salt-key$hash-abcd
// $sha-512$salt-key$hash-abcd
const (
	saltSize = 16
	delmiter = "$"
)

func RandSecret(min int, max int) (string, error) {
	rb := make([]byte, randInt(min, max))
	_, err := rand.Read(rb)
	if err != nil {
		return "", err
	}

	return base64.URLEncoding.EncodeToString(rb), nil
}

func randInt(min int, max int) int {
	return min + mt.Intn(max-min)
}
